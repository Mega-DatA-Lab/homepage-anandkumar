//
//  main.cpp
//  TensorALS
//
//  Created by Majid on 12/26/13.
//  Copyright (c) 2013 Majid. All rights reserved.
//


/* This code implements the non-orthogonal tensor decomposition algorithm proposed in the following paper: http://arxiv.org/abs/1402.5180
 The algorithm basically performs rank-1 updates along each mode of the tensor to recover rank-1 components of the tensor decomposition. The algorithm is closely comparable with Alternating Least Square (ALS) method, where you can find a detailed comparison with ALS in the paper. */


#include <iostream>
//#include <Eigen/Dense>
#include "Eigen/Dense"
#include <random>
#include <chrono>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include <fstream>

using namespace Eigen;
using namespace std;


// This function receives 3 matrices with the same number of columns, and normalizes the columns of these matrices. Furthermore, the product of normalization factors are returned in a vector where each entry includes the product of normalization factors corresponsing to the columns of matrices.
VectorXd SimultaneousColumnNormalization(MatrixXd &, MatrixXd &, MatrixXd &);

// This functions gtes a matrix, and fills its entries with random normal(Mean,StdDev).
void FillGaussianEntries (MatrixXd &mat, const double Mean, const double StdDev );

// This function returns the pseudo-inverse of input matrix
MatrixXd PseudoInverse (const MatrixXd &mat){
    JacobiSVD<MatrixXd> svd(mat, ComputeThinU | ComputeThinV);
    return svd.matrixV() * svd.singularValues().asDiagonal().inverse() * svd.matrixU().transpose();
}

// This function checks the best estimates are close to which of the true ones
void CheckRecoveredColumn (const VectorXd &AestimateBest, const VectorXd &BestimateBest, const VectorXd &CestimateBest, const VectorXd &weightsEstimateCurrent,                            const int IterationBest, const int InitializationCounter,
                            VectorXi &RecoveredColumns, VectorXi &NumRecoveredColumns, VectorXi &ConvergedNotRecoveredColumns, VectorXi &NumConvergedNotRecoveredColumns,
                            double &AvgOverallSquareErrorBest, double &AvgNumIterationsBest, double &AvgWeightsError);


// Checks if current one is better than the old best (in terms of maximum T(a,b,c)). If yes, it updates the best one to current one.
void IsItBetter(const MatrixXd &AestimateCurrent, const MatrixXd &BestimateCurrent, const MatrixXd &CestimateCurrent, const VectorXd &weightsEstimateCurrent,
                const int CurrentIteration,
                VectorXd &AestimateBest, VectorXd &BestimateBest, VectorXd &CestimateBest, VectorXd &weightsEstimateBest, unsigned int &IterationBest);


// This function returns the thin Q of QR decomposition of matrix mat
void Orthogonalize (MatrixXd &mat);


// This function computes the SVD initialization output in mat1 and mat2
void SVD_initialization_function (MatrixXd &mat1, MatrixXd &mat2);


// Global variables

// Size of matrices
const unsigned int d = 100;
const unsigned int k = 200;
// The number of iterations (for running algorithm once), initializations (for a random generated model), and random runs
const unsigned int IterationsMax = 200, InitMax = 1000, NumRun = 10;
// Initialization method
const bool SVD_initialization = false;
// Symmetric or non-symmetric tensor, initialization and update
const bool SymmetricTensor = false;
const bool SymmetricInit = SymmetricTensor;
const bool SymmetricUpdate = SymmetricTensor;
// Orthogonal components or not
const bool OrthogonalComponents = false;
// Unit weights or not
const bool UnitWeights = true;
const double UnitWeightsValue = 1.0/k;

// Parameters for generating random matrices and tensors
const double Mean = 0;
const double StdDev = 1;

// Parameters for LVMs experiments
const bool LVMsExperiments = true;
const unsigned int n = 500; //10 * log(k) * k;
// Multiview Linear Mixture Models
const double zeta = 0.1/sqrt(d);

// Recovery threshold to see if the current estimate is a good one for the closeset true column
// const double Recovery_Threshold = 0.01 * pow(log(d),2) * sqrt(k) / d;
// In case of Multiview Gaussian mixtures, an additional noise term is also added (LOW NOISE regime considered)
const double Recovery_Threshold =  0.001 * pow(log(d),2) * sqrt(k/n) + 0.01 * pow(log(d),2) * sqrt(k) / d; //  max( pow(log(d),2) * sqrt(k) / d, pow(log(d),3) * k / pow(d, 1.5)) //0.5 * log(d) * max( sqrt(k) / d, k / pow(d, 1.5));
const double Terminating_Threshold = 0.00001 * Recovery_Threshold;


// A,B, and C are d-by-k matrices with double floating-point values.
MatrixXd Atrue(d,k), Btrue(d,k), Ctrue(d,k);
VectorXd weightsTrue(k);


int main()
{
    
    // Introducing output variables
    VectorXi RecoveredColumns(k); // Indicates which columns are recovered at the end
    VectorXi ConvergedNotRecoveredColumns(k); // Indicates which columns are the output of algorithm, but not satisfying Recovery Threshold
    VectorXd AvgNumRecoveredColumns(InitMax); // Number of accumulated recovered columns after each new initilization (average over different random runs)
    VectorXd AvgNumConvergedNotRecoveredColumns(InitMax); // Number of accumulated coverged, but NOT recovered columns after each new initilization (average over different random runs)
    double AvgNumIterations = 0; // Average number of iterations which results the best estimation (in terms of max T(a,b,c)) over all initializations
    double AvgOverallSquareErrorBest = 0; // Average overall square error over all initializations
    double AvgWeightsError = 0; // Average error in the estimation of weights
    
    // Temporary variables
    // VectorXd AestimateBest(d), BestimateBest(d), CestimateBest(d);
    // VectorXd weightsEstimateBest(1); // Stores the best result among all different iterations for each Initializations.
    MatrixXd AestimateCurrent(d,1), BestimateCurrent(d,1), CestimateCurrent(d,1);
    MatrixXd AestimateOld(d,1), BestimateOld(d,1), CestimateOld(d,1);
    VectorXd weightsEstimateCurrent(1), weightsEstimateCurrent_new(1);
    VectorXi NumRecoveredColumns = VectorXi::Constant(InitMax, 0), NumConvergedNotRecoveredColumns = VectorXi::Constant(InitMax, 0);
    unsigned int iteration_counter = 0;
    MatrixXd Aestimate_unnormalized(d,1), Bestimate_unnormalized(d,1), Cestimate_unnormalized(d,1);
    bool Termination_condition;
    
    
    time_t tstart, tend;
    tstart = time(0);
    
    
    // Different random runs
    for (int RandomRun = 1; RandomRun <= NumRun; RandomRun++) {
    
        // Generating a random synthetic tensor T through its components A, B, and C
    
        // A, B, and C are filled by random independent Gaussian entries, i.e., normal(Mean,StdDev), and then the columns are normalized.
        // When Mean = 0, StdDev = 1 (which is the case here), the columns of A, B, and C are uniformly drawn at random from the unit sphere in R^d.
        FillGaussianEntries (Atrue, Mean, StdDev );
        if (SymmetricTensor) {
            Btrue = Atrue;
            Ctrue = Atrue;
        } else {
            FillGaussianEntries (Btrue, Mean, StdDev );
            FillGaussianEntries (Ctrue, Mean, StdDev );
        }
        
        if (OrthogonalComponents) {
            if (k > d)
                cout << "No orthogonalization can be performed since the number of columns is more than the number of rows";
            else {
                Orthogonalize (Atrue);
                Orthogonalize (Btrue);
                Orthogonalize (Ctrue);
            }
        }
        
        weightsTrue = SimultaneousColumnNormalization(Atrue, Btrue, Ctrue);  // Normalizing the columns of A, B, and C
        
        if (UnitWeights == true)
            weightsTrue = VectorXd::Constant(k, UnitWeightsValue);  // Set weights as UnitWeightsValue
        
        // Generating samples if the experiments are for some LVM
        // Multiview Linear Mixture Models
        MatrixXd X1(d,n), X2(d,n), X3(d,n);

        // Generating noise matrices with each column a Gaussian vector with mean 0 and standard deviation zeta for each entry.
        MatrixXd NoiseA(d,n), NoiseB(d,n), NoiseC(d,n);
        FillGaussianEntries (NoiseA, 0, zeta );
        FillGaussianEntries (NoiseB, 0, zeta );
        FillGaussianEntries (NoiseC, 0, zeta );
        
        /*// Normalize the weight vector to represent the prior over hidden states
        weightsTrue = weightsTrue / weightsTrue.sum();*/

        // Assume the weights over hidden states are UNIFORM
        unsigned int HiddenState;
        /*unsigned seed = static_cast<unsigned>( chrono::system_clock::now().time_since_epoch().count() );
        default_random_engine generator(seed);
        //ranlux64_base_01 generator(seed);
        
        uniform_int_distribution<int> distribution(0,k-1);*/
        
        for (int j = 0; j <= n-1; j++) {
            //HiddenState = distribution(generator);
            HiddenState = j % k;
            X1.col(j) = Atrue.col(HiddenState) + NoiseA.col(j);
            X2.col(j) = Btrue.col(HiddenState) + NoiseB.col(j);
            X3.col(j) = Ctrue.col(HiddenState) + NoiseC.col(j);
        }

    
        // No column is recovered in the beginning
        RecoveredColumns = VectorXi::Constant(k, 0);
        ConvergedNotRecoveredColumns = VectorXi::Constant(k, 0);

        
        // Different Initializations
        for (int InitializationCounter = 1; InitializationCounter <= InitMax; InitializationCounter++) {
            
            // AestimateCurrent and BestimateCurrent are randomly initialized with Gaussian entries, and then normalized. Therefore, AestimateCurrent and BestimateCurrent are uniformly drawn at random from the unit sphere in R^d.
            if (SVD_initialization) {
                SVD_initialization_function (AestimateCurrent, BestimateCurrent);
                // CestimateCurrent is initialized as one step of iterating updates
                CestimateCurrent = Ctrue * weightsTrue.asDiagonal() * (Atrue.transpose()*AestimateCurrent).cwiseProduct(Btrue.transpose()*BestimateCurrent);
            }
            else {
                FillGaussianEntries (AestimateCurrent, Mean, StdDev);
                if (SymmetricInit) {
                    BestimateCurrent = AestimateCurrent;
                    CestimateCurrent = AestimateCurrent;
                }
                else {
                    FillGaussianEntries (BestimateCurrent, Mean, StdDev);
                    CestimateCurrent = Ctrue * weightsTrue.asDiagonal() * (Atrue.transpose()*AestimateCurrent).cwiseProduct(Btrue.transpose()*BestimateCurrent);
                }
            }


            weightsEstimateCurrent = SimultaneousColumnNormalization(AestimateCurrent, BestimateCurrent, CestimateCurrent); // Normalization
            weightsEstimateCurrent(0) = pow(weightsEstimateCurrent(0), 1.0/3); // The estimated weight is the 3rd root product of norms
        

            // Running the alternating algorithm
            iteration_counter = 0;
            Termination_condition = 0;
            
            // Depending on if the experiments are running on LVMs or on synthetic true tensor, the active matrices for power updates are different
            MatrixXd Aactive, Bactive, Cactive;
            VectorXd weightsActive;
            if (LVMsExperiments == false) {
                Aactive = Atrue;
                Bactive = Btrue;
                Cactive = Ctrue;
                weightsActive = weightsTrue;
            } else {
                Aactive = X1;
                Bactive = X2;
                Cactive = X3;
                weightsActive.setOnes(n); weightsActive = weightsActive/n;
            }

            
            do {
                
                iteration_counter++;
                
                // Save the old updates to compare later with the new ones for convergence
                AestimateOld = AestimateCurrent; BestimateOld = BestimateCurrent; CestimateOld = CestimateCurrent;
                
                // Main updates
                Aestimate_unnormalized = Aactive * weightsActive.asDiagonal() * (Bactive.transpose()*BestimateCurrent).cwiseProduct(Cactive.transpose()*CestimateCurrent);
                if (SymmetricUpdate) { // This is the symmetric power update when we also have Symmetric tensor T and Symmetric initialization
                    Bestimate_unnormalized = Aestimate_unnormalized;
                    Cestimate_unnormalized = Aestimate_unnormalized;
                }
                else { // This is Asymmetric power update which we propose
                    Bestimate_unnormalized = Bactive * weightsActive.asDiagonal() * (Aactive.transpose()*AestimateCurrent).cwiseProduct(Cactive.transpose()*CestimateCurrent);
                    Cestimate_unnormalized = Cactive * weightsActive.asDiagonal() * (Aactive.transpose()*AestimateCurrent).cwiseProduct(Bactive.transpose()*BestimateCurrent);
                }
                // Normalization
                weightsEstimateCurrent = SimultaneousColumnNormalization(Aestimate_unnormalized, Bestimate_unnormalized, Cestimate_unnormalized);
                weightsEstimateCurrent(0) = pow(weightsEstimateCurrent(0), 1.0/3); // The estimated weight is the 3rd root product of norms
                // After returning from normalization function, the unnormalized variables are also normalized
                AestimateCurrent = Aestimate_unnormalized; BestimateCurrent = Bestimate_unnormalized; CestimateCurrent = Cestimate_unnormalized;
                
                
                weightsEstimateCurrent_new = AestimateCurrent.transpose() * Aactive * weightsActive.asDiagonal() * (Bactive.transpose()*BestimateCurrent).cwiseProduct(Cactive.transpose()*CestimateCurrent);
                cout << "Eigenvalue estimation at the end of iteration " << iteration_counter << " is " << weightsEstimateCurrent_new << endl;
                
                
                if ( (AestimateCurrent - AestimateOld).squaredNorm() <= Terminating_Threshold &&
                     (BestimateCurrent - BestimateOld).squaredNorm() <= Terminating_Threshold &&
                     (CestimateCurrent - CestimateOld).squaredNorm() <= Terminating_Threshold )
                    Termination_condition = 1;

            } while ( (!Termination_condition ) && iteration_counter < IterationsMax );
            
            // Printing the errors
            /*cout << "The error between the last and previous estimates in this initialization is\tfor A: ";
            cout << fixed;
            cout << setprecision(7) << (AestimateCurrent - AestimateOld).squaredNorm();
            cout << "\tfor B: ";
            cout << fixed;
            cout << setprecision(7) << (BestimateCurrent - BestimateOld).squaredNorm();
            cout << "\tfor C: ";
            cout << fixed;
            cout << setprecision(7) << (CestimateCurrent - CestimateOld).squaredNorm();
            cout << "\n";*/
            

            // After performing the iterations for each initialization, it is checked if a column is recovered
            CheckRecoveredColumn (AestimateCurrent, BestimateCurrent, CestimateCurrent, weightsEstimateCurrent, iteration_counter,  InitializationCounter,     //inputs
                               RecoveredColumns, NumRecoveredColumns, ConvergedNotRecoveredColumns, NumConvergedNotRecoveredColumns, AvgOverallSquareErrorBest, AvgNumIterations, AvgWeightsError) ;    //outputs
        }
    }
    
    
    ofstream Output;
    //Output.open("/Users/Majid/Documents/University/UCI/Research/C++Codes/TensorALS/output_MGM_d100_k20_n100.txt", ios::out); //outputSymmTensorInit
    Output.open("/home/majid/Simulations/output_MGM_d100_k200_n500.txt", ios::out);
    
    // Compute the averages, and saving in the output file
    AvgOverallSquareErrorBest /= (InitMax * NumRun);
    AvgNumIterations /= (InitMax * NumRun);
    AvgWeightsError /= (InitMax * NumRun);
    for (int i = 0; i <= InitMax-1; i++) {
        AvgNumRecoveredColumns(i) = static_cast<double>(NumRecoveredColumns(i)) / NumRun;
        Output << AvgNumRecoveredColumns(i) << "\n";
    }
    Output << "\n";
    for (int i = 0; i <= InitMax-1; i++) {
        AvgNumConvergedNotRecoveredColumns(i) = static_cast<double>(NumConvergedNotRecoveredColumns(i)) / NumRun;
        Output << AvgNumConvergedNotRecoveredColumns(i) << endl;
    }
    Output << "\n" << Recovery_Threshold << "\n" << Terminating_Threshold << "\n\n" << AvgOverallSquareErrorBest << "\n" << AvgWeightsError << "\n" << AvgNumIterations << "\n\n" << n << "\n" << zeta << endl;
    Output.close();
    
    tend = time(0);
    
    
    // Output
    cout << "\nd = " << d << "\nk = " << k
         << "\nMaximum number of iterations = " << IterationsMax
         << "\nNumber of initializations = " << InitMax
         << "\nNumber of random runs = " << NumRun
         << "\nThe recovery threshold is " << Recovery_Threshold
         << "\nThe terminating threshold is " << Terminating_Threshold;
    
    cout << "\n\nThe following columns are recovered at the end of last run:\n";
    for (int j = 0; j <= k-1; j++) {
        if (RecoveredColumns(j) == 1)
            cout << j << "  ";
    }
    cout << "\nand the following columns are recovered, but do not satisfy the recovery threshold criteria:\n";
    for (int j = 0; j <= k-1; j++) {
        if (ConvergedNotRecoveredColumns(j) == 1)
            cout << j << "  ";
    }
    
    cout << "\n\nThe average overall square error in recovery is " << AvgOverallSquareErrorBest
         << "\nThe average square error in recovering weights is " << AvgWeightsError
         << "\nThe average number of iterations for getting best recovered columns is " << AvgNumIterations
         << "\n\nThe following number of columns are recovered after each initialization\n";
    cout << setprecision(1) << AvgNumRecoveredColumns.transpose();
    cout << "\n\nand the following number of columns are converged, but not recovered after each initialization\n";
    cout << setprecision(1) << AvgNumConvergedNotRecoveredColumns.transpose() << "\n\n";
    /*cout << Atrue << "\n\n" << Btrue << "\n\n" << Ctrue << "\n\n" << weights << "\n\n";
    cout << "Atrue =\n" << Atrue << "\n\n" << "Aestimate =\n" << AestimateBest << "\n\n\n"
         << "Btrue =\n" << Btrue << "\n\n" << "Bestimate =\n" << BestimateBest << "\n\n\n"
         << "Ctrue =\n" << Ctrue << "\n\n" << "Cestimate =\n" << CestimateBest << "\n\n\n"
         << "weightsTrue =\n" << weightsTrue << "\n\n" << "weightsEstimate =\n" << weightsEsimateBest <<"\n\n\n"
    
         << "The closest true column to the current estimation is (Rows = Iteartions, Columns = Initializations)\n" << ClosestColumn;
         << "\n\nAnd the trend of closeness from each iteration to next one is as\n" << IterartionsTrend
    
         << "\n\nThe best estimation (in terms of maximum T(a,b,c)) happens in iteration " << IterationBest <<" of initialization number " << InitializationBest
         << "\n\nThe closest column is\n" << ClosestColumnBest;
         << "\nwith overall square error equal to\n" << OverallSquareErrorBest << "\n\n"
         << "The ratio of entries in deifferent columns are\n" << EntriesRatio << "\n\n";
    
    cout << Atrue + AestimateCurrent << "\n\n\n" << Btrue + BestimateCurrent << "\n\n\n" << Ctrue + CestimateCurrent << "\n\n\n" << weightsTrue + weightsEsimateCurrent <<"\n\n\n";
    cout << Atrue - AestimateCurrent << "\n\n\n" << Btrue - BestimateCurrent << "\n\n\n" << Ctrue - CestimateCurrent << "\n\n\n" << weightsTrue - weightsEsimateCurrent <<"\n\n\n";*/
    
    
    cout << "It took "<< difftime(tend, tstart) <<" second(s).\n\n";
    
    
    return 0;
}


void FillGaussianEntries (MatrixXd &mat, const double Mean, const double StdDev ) {
    
    const unsigned long int NumberRows = mat.rows();
    const unsigned long int NumberColumns = mat.cols();

    // construct a trivial random generator engine from a time-based seed:
    unsigned seed = static_cast<unsigned>( chrono::system_clock::now().time_since_epoch().count() );
    //default_random_engine generator(seed);
    ranlux64_base_01 generator(seed);
    
    normal_distribution<double> distribution(Mean,StdDev);
    //uniform_real_distribution<double> distribution(0.0,1.0);
    
    for (int i = 0; i <= NumberRows-1; i++)
        for (int j = 0; j <= NumberColumns-1; j++)
            mat(i,j) = distribution(generator);
    
}


VectorXd SimultaneousColumnNormalization(MatrixXd &mat1, MatrixXd &mat2, MatrixXd &mat3) {
    
    const unsigned long int NumberColumns = mat1.cols();
    
    VectorXd NormalizationVector(NumberColumns);
    
    for (int j=0; j <= NumberColumns-1; j++) {  // Note that the coulmns of matrices are indexed from 0 to NumberColumns-1
        NormalizationVector(j) = mat1.col(j).norm() * mat2.col(j).norm() * mat3.col(j).norm();
        mat1.col(j).normalize();
        mat2.col(j).normalize();
        mat3.col(j).normalize();
    }
    
    return NormalizationVector;
}


void Orthogonalize (MatrixXd &mat) {
    
    const unsigned long int NumberRows = mat.rows();
    const unsigned long int NumberColumns = mat.cols();
    
    MatrixXd thinQ(MatrixXd::Identity(NumberRows,NumberColumns)), Q;
    
    HouseholderQR<MatrixXd> qr(mat);
    Q = qr.householderQ();
    thinQ = qr.householderQ() * thinQ;
    mat = thinQ;
    
}


void SVD_initialization_function(MatrixXd &mat1, MatrixXd &mat2) {
    
    const unsigned long int NumberRows1 = mat1.rows();
    const unsigned long int NumberRows2 = mat2.rows();
    const unsigned long int NumberRows3 = Ctrue.rows();
    const unsigned long int NumberColumns = mat1.cols();
    
    MatrixXd theta(NumberRows3,1);
    VectorXd lambda(k);
    MatrixXd T_IItheta(NumberRows1,NumberRows2);
    
    for (int j = 0; j <= NumberColumns-1; j++) {
        
        FillGaussianEntries(theta, Mean, StdDev);
        // Computing T(I,I,theta)
        lambda = weightsTrue.asDiagonal() * Ctrue.transpose() * theta; // lambda = Diag(w) C^T theta
        T_IItheta = Atrue * lambda.asDiagonal() * Btrue.transpose(); // T(I,I,theta) = A Diag(lambda) B^T
        
        // Computing the top singular vectors of T(I,I,theta) as initializations
        JacobiSVD<MatrixXd> svd(T_IItheta, ComputeThinU | ComputeThinV);
        mat1.col(j) = svd.matrixU().col(0);
        mat2.col(j) = svd.matrixV().col(0);
    }
    
}

void IsItBetter(const MatrixXd &AestimateCurrent, const MatrixXd &BestimateCurrent, const MatrixXd &CestimateCurrent, const VectorXd &weightsEstimateCurrent,
                const int CurrentIteration,
                VectorXd &AestimateBest, VectorXd &BestimateBest, VectorXd &CestimateBest, VectorXd &weightsEstimateBest, unsigned int &IterationBest) {
    
    double CurrentValue = 0;
    static double BestValue = 0; // BestValue should be kept when exiting the function
    
    for (int j = 0; j <= k-1; j++) // This for loop computes T(AestimateCurrent, BestimateCurrent, CestimateCurrent)
        CurrentValue += weightsTrue(j) * Atrue.col(j).dot(AestimateCurrent.col(0)) * Btrue.col(j).dot(BestimateCurrent.col(0)) * Ctrue.col(j).dot(CestimateCurrent.col(0));
    
    if ( (CurrentValue > BestValue) || (CurrentIteration == 1) ) { // In the first iteration, the if condition is true
        BestValue = CurrentValue;
        AestimateBest = AestimateCurrent;
        BestimateBest = BestimateCurrent;
        CestimateBest = CestimateCurrent;
        weightsEstimateBest = weightsEstimateCurrent;
        IterationBest = CurrentIteration;
    }
}


void CheckRecoveredColumn (const VectorXd &AestimateBest, const VectorXd &BestimateBest, const VectorXd &CestimateBest, const VectorXd &weightsEstimateCurrent,
                            const int IterationBest, const int InitializationCounter,
                            VectorXi &RecoveredColumns, VectorXi &NumRecoveredColumns, VectorXi &ConvergedNotRecoveredColumns, VectorXi &NumConvergedNotRecoveredColumns,
                            double &AvgOverallSquareErrorBest, double &AvgNumIterations, double &AvgWeightsError) {
    
    int ClosestColumn;
    double OverallDotProductBest = 0, OverallDotProductTemp = 0, OverallSquareErrorBest = 0;
    Vector4d DotProducts;
    
    // This part checks the current best estimate (in this initialization) corresponds to which true column?
    // which columns are the closeset ones for these recovered vectors?
    // argmax_j |<Aestimate, Atrue_j>| + |<Bestimate, Btrue_j>| + |<Cestimate, Ctrue_j>|
    for (int j = 0; j <= k-1; j++) {
        
        // Because of sign ambiguity, we need to consider four cases and takes the maximum
        if (SymmetricUpdate) { //This is for the case we have Symmetric initialization and tensor too.
            DotProducts(0) = 3 * Atrue.col(j).dot(AestimateBest);
            DotProducts(1) = DotProducts(0); DotProducts(2) = DotProducts(0); DotProducts(3) = DotProducts(0); //we repeat first entry to make sure redundant entries 1,2,3 do not cause any problem
        }
        else {
            DotProducts(0) = Atrue.col(j).dot(AestimateBest) + Btrue.col(j).dot(BestimateBest) + Ctrue.col(j).dot(CestimateBest);
            DotProducts(1) = Atrue.col(j).dot(AestimateBest) - Btrue.col(j).dot(BestimateBest) - Ctrue.col(j).dot(CestimateBest);
            DotProducts(2) = - Atrue.col(j).dot(AestimateBest) + Btrue.col(j).dot(BestimateBest) - Ctrue.col(j).dot(CestimateBest);
            DotProducts(3) = - Atrue.col(j).dot(AestimateBest) - Btrue.col(j).dot(BestimateBest) + Ctrue.col(j).dot(CestimateBest);
        }
        OverallDotProductTemp = DotProducts.maxCoeff();
        //Absolute value is for compensating the sign ambiguity issue in recovery
        //OverallDotProductTemp = abs ( Atrue.col(j).dot(AestimateBest) ) + abs ( Btrue.col(j).dot(BestimateBest) ) + abs ( Ctrue.col(j).dot(CestimateBest) );
        
        if ( (OverallDotProductTemp > OverallDotProductBest ) || (j==0) ) {
            ClosestColumn = j;
            OverallDotProductBest = OverallDotProductTemp;
        }
    }
    
    // OverallSquareErrorBest = min_{\pm} || Atrue_ClosestColumn \pm Aestimate ||^2 + || Atrue_ClosestColumn \pm Aestimate ||^2 + || Atrue_ClosestColumn \pm Aestimate ||^2
    OverallSquareErrorBest = 2 - 2 * OverallDotProductBest / 3;
    
    // Check if the current estimate is a good one for the closeset true column
    if ( OverallSquareErrorBest <= Recovery_Threshold )
        {RecoveredColumns(ClosestColumn) = 1; ConvergedNotRecoveredColumns(ClosestColumn) = 0;}
    else if ( RecoveredColumns(ClosestColumn) == 0 )
        ConvergedNotRecoveredColumns(ClosestColumn) = 1;
    
    // Compute the number of columns recovered till this initilization (inclusive)
    NumRecoveredColumns(InitializationCounter - 1) += RecoveredColumns.sum();
    NumConvergedNotRecoveredColumns(InitializationCounter - 1) += ConvergedNotRecoveredColumns.sum();
    
    // Output
    cout << "Column " << ClosestColumn << " is recovered with overall square error ";
    cout << fixed;
    cout << setprecision(7) << OverallSquareErrorBest;
    cout << " in iteration " << IterationBest << " of initialization " << InitializationCounter << endl;
    
    AvgOverallSquareErrorBest += OverallSquareErrorBest;
    AvgWeightsError += pow( abs( weightsTrue(ClosestColumn)-weightsEstimateCurrent(0) ) / weightsTrue(ClosestColumn), 2 );
    AvgNumIterations += IterationBest;
    
}