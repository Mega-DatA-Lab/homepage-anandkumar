clear all
clc
beta=0.1;alpha=0.2-beta;
p=80;
k=2;c=1;nStates=2;

addpath ./tools


Jcycle=graph2adj_cycle(p,alpha,beta);
adjcycle=Jcycle;adjcycle(Jcycle~=0)=1;
k_cy=sum(sum((adjcycle)));

JER=graph2adj_ER(p,c,alpha,beta);
adjER=JER;adjER(JER~=0)=1;
k_er=sum(sum((adjER)));

JWS=graph2adj_WS(p,k,c,alpha,beta);
adjWS=JWS;adjWS(JWS~=0)=1;
k_ws=sum(sum((adjWS)));

for i=1:length(Jcycle(:))
    if rand(1)<0.5
        Jcycle(i)=-Jcycle(i);
        JER(i)=-JER(i);
        JWS(i)=-JWS(i);
    end
        
end

for i=1:p
    jj=1;
    for j=1:p
        if i~=j
            adjj_cy(i,jj)=adjcycle(i,j);
            adjj_er(i,jj)=adjER(i,j);
            adjj_ws(i,jj)=adjWS(i,j);
            jj=jj+1;
        end
    end
end

nn=1;
for n=[10^2,5*10^2,10^3,5*10^3,10^4,10^5]
   
    LearningDatacycle=double(SampleLearn(p, nStates, n,adjcycle, Jcycle));
    LearningDataER=double(SampleLearn(p, nStates, n,adjER, JER));
    LearningDataWS=double(SampleLearn(p, nStates, n,adjWS, JWS));
    
    
    lam=sqrt(log(p)/n);
    lambda=[100*lam,1000*lam,10000*lam,100000*lam,1000000*lam];
       
    for ll=1:length(lambda)
        %% L1 General
        for r=1:p
            
            %% cycle graph
            temp_cy=LearningDatacycle;
            temp_cy(:,r)=[];
            X_cy=temp_cy;
            [nInstances_cy,nVars_cy]=size(X_cy);
            y_cy=LearningDatacycle(:,r);
            %X=[ones(nInstances,1) X];% Add Bias element to features
            funObj_cy = @(w_cy)LogisticLoss(w_cy,X_cy,y_cy);
            w_init_cy = zeros(nVars_cy,1);
            %lambda
            lambdaVect = lambda(ll)*ones(nVars_cy,1);
            % L1-Regularized Logistic Regression
            %fprintf('\nComputing L1-Regularized Logistic Regression Coefficients...\n');
            wLogL1_cy = L1GeneralProjection(funObj_cy,w_init_cy,lambdaVect);
            theta_cy(r,:,ll)=0.5*wLogL1_cy;
            
            %% er graph
            temp_er=LearningDataER;
            temp_er(:,r)=[];
            X_er=temp_er;
            [nInstances_er,nVars_er]=size(X_er);
            y_er=LearningDataER(:,r);
            %X=[ones(nInstances,1) X];% Add Bias element to features
            funObj_er = @(w_er)LogisticLoss(w_er,X_er,y_er);
            w_init_er = zeros(nVars_er,1);
            %lambda
            lambdaVect = lambda(ll)*ones(nVars_er,1);
            % L1-Regularized Logistic Regression
            %fprintf('\nComputing L1-Regularized Logistic Regression Coefficients...\n');
            wLogL1_er = L1GeneralProjection(funObj_er,w_init_er,lambdaVect);
            theta_er(r,:,ll)=0.5*wLogL1_er;
            
            %% ws graph
            temp_ws=LearningDataWS;
            temp_ws(:,r)=[];
            X_ws=temp_ws;
            [nInstances_ws,nVars_ws]=size(X_ws);
            y_ws=LearningDataWS(:,r);
            %X=[ones(nInstances,1) X];% Add Bias element to features
            funObj_ws = @(w_ws)LogisticLoss(w_ws,X_ws,y_ws);
            w_init_ws = zeros(nVars_ws,1);
            %lambda
            lambdaVect = lambda(ll)*ones(nVars_ws,1);
            % L1-Regularized Logistic Regression
            %fprintf('\nComputing L1-Regularized Logistic Regression Coefficients...\n');
            wLogL1_ws = L1GeneralProjection(funObj_ws,w_init_ws,lambdaVect);
            theta_ws(r,:,ll)=0.5*wLogL1_ws;
        end
        adjjhat_cy=theta_cy(:,:,ll)~=0;
        adjjhat_er=theta_er(:,:,ll)~=0;
        adjjhat_ws=theta_ws(:,:,ll)~=0;
        
        norEdges_cy(nn,ll)=sum(sum(adjjhat_cy))/2;
        norEdges_er(nn,ll)=sum(sum(adjjhat_er))/2;
        norEdges_ws(nn,ll)=sum(sum(adjjhat_ws))/2;
        norEdit_cy(nn,ll)=sum(sum(xor(adjjhat_cy,adjj_cy)))/k_cy;
        norEdit_er(nn,ll)=sum(sum(xor(adjjhat_er,adjj_er)))/k_er;
        norEdit_ws(nn,ll)=sum(sum(xor(adjjhat_ws,adjj_ws)))/k_ws;
    end
    nn=nn+1;
end

