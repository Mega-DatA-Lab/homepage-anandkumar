function J = graph2adj_cycle (p,alpha,beta)

% Star Graph 
% Inputand the star center c and number of nodes p.
% Output Inverse Covariance Matrix.
% For Gaussian, Sigma^(-1)=J=I-R;
% alpha is the bound for the entries of R.
J=zeros(p,p);

for i=1:p
    for j=i+1:p
        if j-i==1
            J(i,j)=rand(1)*alpha+beta;
            J(j,i)=rand(1)*alpha+beta;
        end
    end
%     for j=1:i-1
%         J(i,j)=J(j,i);
%     end
end
% J(p,p-1)=J(p-1,p);
J(1,p)=rand(1)*alpha+beta;
J(p,1)=rand(1)*alpha+beta;
