clear all
clc
beta=0.1;alpha=0.2-beta;
% J_max_ER=atanh(1/c) when c=1 atanh(1)=inf
% J_max_cycle=atanh(1/2)
k=2;c=1;
p=80;nStates = 2; 

Jcycle=graph2adj_cycle(p,alpha,beta);
adjcycle=Jcycle;adjcycle(Jcycle~=0)=1;

JER=graph2adj_ER(p,c,alpha,beta);
adjER=JER;adjER(JER~=0)=1;

JWS=graph2adj_WS(p,k,c,alpha,beta);
adjWS=JWS;adjWS(JWS~=0)=1;

for i=1:length(Jcycle(:))
    if rand(1)<0.5
        Jcycle(i)=-Jcycle(i);
        JER(i)=-JER(i);
        JWS(i)=-JWS(i);
    end
        
end

runs=1;
for n=[10^2,5*10^2,10^3,5*10^3,10^4,10^5] 
LearningDatacycle=double(SampleLearn(p, nStates, n,adjcycle, Jcycle));
MuInfo_cycle(:,:,runs)= minMuInfo_S2(LearningDatacycle);
LearningDataER=double(SampleLearn(p, nStates, n,adjER, JER));
MuInfo_ER(:,:,runs)= minMuInfo_S2(LearningDataER);
LearningDataWS=double(SampleLearn(p, nStates, n,adjWS, JWS));
MuInfo_WS(:,:,runs)= minMuInfo_S4(LearningDataWS);

Thres=[0.0001,0.0002,0.0003,0.0004,0.0005,0.0006,0.0007,0.0008,0.0009,0.0010,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009,0.010,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.2,0.3,0.4,0.5];

    for tt=1:length(Thres)
        %% CYCLE 
        J_candidate=zeros(p,p);
        J_candidate(MuInfo_cycle(:,:,runs)>Thres(tt))=1;
        J_candidate=(triu(J_candidate,1))'+triu(J_candidate,1);
        JJ(tt).hatcycle=J_candidate;
        
        J_candidate=zeros(p,p);
        J_candidate(MuInfo_ER(:,:,runs)>Thres(tt))=1;
        J_candidate=(triu(J_candidate,1))'+triu(J_candidate,1);
        JJ(tt).hatER=J_candidate;
        
        J_candidate=zeros(p,p);
        J_candidate(MuInfo_WS(:,:,runs)>Thres(tt))=1;
        J_candidate=(triu(J_candidate,1))'+triu(J_candidate,1);
        JJ(tt).hatWS=J_candidate;

         
        D1cycle=zeros(p,p); D1cycle(Jcycle~=0)=1;
        k_cy=sum(sum(D1cycle));
        Dhat1cycle=JJ(tt).hatcycle;
        E1cycle=double(xor(D1cycle,Dhat1cycle));
        noEdges_cycle(runs,tt)=sum(sum(triu(Dhat1cycle,1)));
        norEditDiscycle(runs,tt)=sum(sum(E1cycle))/k_cy;
        
        D1ER=zeros(p,p); D1ER(JER~=0)=1;
        k_ER=sum(sum(D1ER));
        %Dhat1ER=zeros(p,p);        Dhat1ER(JJ(tt).hatER<0)=1;
        Dhat1ER=JJ(tt).hatER;
        E1ER=double(xor(D1ER,Dhat1ER));
        noEdges_er(runs,tt)=sum(sum(triu(Dhat1ER,1)));
        norEditDisER(runs,tt)=sum(sum(E1ER))/k_ER;
        
        D1WS=zeros(p,p); D1WS(JWS~=0)=1;
        k_WS=sum(sum(D1WS));
        %Dhat1WS=zeros(p,p);        Dhat1WS(JJ(tt).hatWS<0)=1;
        Dhat1WS=JJ(tt).hatWS;
        E1WS=double(xor(D1WS,Dhat1WS));
        noEdges_ws(runs,tt)=sum(sum(triu(Dhat1WS,1)));
        norEditDisWS(runs,tt)=sum(sum(E1WS))/k_WS;
     end
    runs=runs+1;
end  
