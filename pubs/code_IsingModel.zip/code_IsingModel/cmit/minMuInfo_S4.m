function minMu_S= minMuInfo_S4(LearningData)
%% Enumerate separator sets
p=length(LearningData(1,:));
minMu_S=zeros(p,p);
for i=1:p
    for j=i+1:p
        SS=1:p;
        SS(i)=[]; SS(j-1)=[];
        S(i,j).S1=combnk(SS,1);
        %          S(i,j).S2=combnk(SS,2);
        %          S(i,j).S3=combnk(SS,3);
        %          S(i,j).S4=combnk(SS,4);
    end
end

%% Find the minMu for each pair i~j

for i=1:p
    for j=i+1:p
        for l=1:length(S(i,j).S1)
           Mu_S1(l,1)=condmutualinfo(LearningData(:,i),LearningData(:,j),LearningData(:,S(i,j).S1(l)));       
        end
        [valuemin1,index]=min(Mu_S1);
        indexv=S(i,j).S1(index);
        S(i,j).S2(:,2)=indexv*ones((length(S(i,j).S1)-1),1);
        middlething=S(i,j).S1;
        middlething(middlething==indexv)=[];
        S(i,j).S2(:,1)=middlething;
        
        for l=1:length(S(i,j).S2(:,1))
           Mu_S2(l,1)=condmutualinfo(LearningData(:,i),LearningData(:,j),LearningData(:,S(i,j).S2(l,:)));
        end
        [valuemin2,index2]=min(Mu_S2);
        indexv2=S(i,j).S2(index2,:);
        S(i,j).S3(:,3)=indexv*ones(length(S(i,j).S2(:,1))-1,1);
        S(i,j).S3(:,2)=indexv2(:,1)*ones(length(S(i,j).S2(:,1))-1,1);
        middlething2=S(i,j).S2(:,1);
        middlething2(middlething2==indexv2(:,1))=[];
        S(i,j).S3(:,1)=middlething2;
        
        for l=1:length(S(i,j).S3(:,1))
            Mu_S3(l,1)=condmutualinfo(LearningData(:,i),LearningData(:,j),LearningData(:,S(i,j).S3(l,:)));
            
        end
        %%
        [valuemin3,index3]=min(Mu_S3);
        indexv3=S(i,j).S3(index3,:);
        S(i,j).S4(:,4)=indexv*ones(length(S(i,j).S3(:,1))-1,1);
        S(i,j).S4(:,3)=indexv2(:,1)*ones(length(S(i,j).S3(:,1))-1,1);
        S(i,j).S4(:,2)=indexv3(:,1)*ones(length(S(i,j).S3(:,1))-1,1);
        middlething3=S(i,j).S3(:,1);
        middlething3(middlething3==indexv3(:,1))=[];
        S(i,j).S4(:,1)=middlething3;
        
        for l=1:length(S(i,j).S4(:,1))
           Mu_S4(l,1)=condmutualinfo(LearningData(:,i),LearningData(:,j),LearningData(:,S(i,j).S4(l,:))); 
        end
        [valuemin4,index4]=min(Mu_S4);
        minMu_S(i,j)=min([valuemin1,valuemin2,valuemin3,valuemin4]);
    end
end
