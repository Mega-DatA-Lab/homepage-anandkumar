function LearningData=SampleLearn(nNodes, nStates, n,adj,J)
%% Sampling 
%Ising Model with h=0;
burnIn=100000;
edgeStruct = UGM_makeEdgeStruct(adj,nStates);
edgeStruct.maxIter =n;
nodePot = 0.5*ones(nNodes,nStates);
maxState = max(edgeStruct.nStates);
edgePot = zeros(maxState,maxState,edgeStruct.nEdges);
for e=1:edgeStruct.nEdges
    u=edgeStruct.edgeEnds(e,1);
    v=edgeStruct.edgeEnds(e,2);
    edgePot(1,1,e)=exp(0.5*[-1,-1]*[0,J(u,v);J(u,v),0]*[-1;-1]);
    edgePot(1,2,e)=exp(0.5*[-1,1]*[0,J(u,v);J(u,v),0]*[-1;1]);
    edgePot(2,1,e)=exp(0.5*[1,-1]*[0,J(u,v);J(u,v),0]*[1;-1]);
    edgePot(2,2,e)=exp(0.5*[1,1]*[0,J(u,v);J(u,v),0]*[1;1]);
    summation=edgePot(1,1,e)+edgePot(1,2,e)+edgePot(2,1,e)+edgePot(2,2,e);
    edgePot(1,1,e)=edgePot(1,1,e)/summation;
    edgePot(1,2,e)=edgePot(1,2,e)/summation;
    edgePot(2,1,e)=edgePot(2,1,e)/summation;
    edgePot(2,2,e)=edgePot(2,2,e)/summation;
end
LearningData= UGM_Sample_Gibbs(nodePot,edgePot,edgeStruct,burnIn);
LearningData(LearningData==1)=-1;
LearningData(LearningData==2)=1;
LearningData=LearningData';