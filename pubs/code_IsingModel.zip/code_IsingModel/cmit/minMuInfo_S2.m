function minMu_S= minMuInfo_S2(LearningData)
%clear all; clc; load LearningData;
%% Enumerate separator sets
p=length(LearningData(1,:));
minMu_S=zeros(p,p);
for i=1:p
    for j=i+1:p
        SS=1:p;
        SS(i)=[]; SS(j-1)=[];
        S(i,j).S1=combnk(SS,1);
        S(j,i).S1=S(i,j).S1;
%         S(i,j).S2=combnk(SS,2);
    end
end

%% Find the minMu for each pair i~j
for i=1:p
    for j=i+1:p
        for l=1:length(S(i,j).S1)
            Mu_S1(l,1)=condmutualinfo(LearningData(:,i),LearningData(:,j),LearningData(:,S(i,j).S1(l)));
        end
         [valuemin1,index]=min(Mu_S1);
        indexv=S(i,j).S1(index);
        S(i,j).S2(:,2)=indexv*ones((length(S(i,j).S1)-1),1);
        middlething=S(i,j).S1;
        middlething(middlething==indexv)=[];
        S(i,j).S2(:,1)=middlething;
%         
        for l=1:length(S(i,j).S2(:,1))
            Mu_S2(l,1)=condmutualinfo(LearningData(:,i),LearningData(:,j),LearningData(:,S(i,j).S2(l,:)));
           
        end
        [valuemin2,index]=min(Mu_S2);
        indexv=S(i,j).S2(index,:);
        minMu_S(i,j)=min([valuemin1,valuemin2]);
    end
end
