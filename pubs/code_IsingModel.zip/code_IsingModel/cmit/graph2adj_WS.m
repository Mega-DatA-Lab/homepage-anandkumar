function J = graph2adj_WS (p,k,c,alpha,beta)
% Watts and Strogatz Model(Small World Graph)
A=smallw(p,k,c/p);
A=triu(A,1)+triu(A,1)';
index=find(A>0);
A(index)=rand(length(index),1)*alpha+beta*ones(length(index),1);
J=A;

% Erdos-Reyni Random Graph 
% Inputand the probability of each edge and number of vertices p.
% Output Normalized (diagnol entries ==1)Inverse Covariance Matrix.
% For Gaussian, Sigma^(-1)=J=I-R;
% alpha is the bound for the entries of R.
% p is the no. of vertices
% pr is the probability of an edge between two vertices.

% pr=c/p;
% A=-(rand(p,p)<pr);
% A=triu(A,1); 
% index=find(A<0);
% A(index)=-rand(length(index),1)*alpha;
% A=A+A';
% J=A+eye(p);

