function J = graph2adj_ER (p,c,alpha,beta)
% clear all
% clc
% p=100;alpha=0.1;c=1.1;

pr=c/p;
A=(rand(p,p)<pr);
A=triu(A,1)+triu(A,1)'; 
index=find(A>0);
A(index)=rand(length(index),1)*alpha+beta*ones(length(index),1);
J=A;

% Erdos-Reyni Random Graph 
% Inputand the probability of each edge and number of vertices p.
% Output Normalized (diagnol entries ==1)Inverse Covariance Matrix.
% For Gaussian, Sigma^(-1)=J=I-R;
% alpha is the bound for the entries of R.
% p is the no. of vertices
% pr is the probability of an edge between two vertices.

% pr=c/p;
% A=(rand(p,p)<pr);
% A=triu(A,1)+triu(A,1)'; 
% index=find(A>0);
% A(index)=rand(length(index),1)*alpha+beta*ones(length(index),1);
% %A=A+A';
% J=A;



% From the theory of Erdos-Renyi graphs, we know that a giant connected
% component should emerge when pr>1/(p-1).
% thres_giant=1/(p-1);
% 
% 
% [x y]=draw_dot(A);
% hold on
% figure(2)
% gplot(A,[x' y'], '.-');
