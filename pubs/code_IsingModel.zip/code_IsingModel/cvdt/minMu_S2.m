function minMu_S= minMu_S2(LearningData)
%clear all; clc; load LearningData;
% clear all
% close all
% load LearningData
%% Enumerate separator sets
p=length(LearningData(1,:));
minMu_S=zeros(p,p);
for i=1:p
    for j=i+1:p
        SS=1:p;
        SS(i)=[]; SS(j-1)=[];
        S(i,j).S1=combnk(SS,1);
        S(j,i).S1=S(i,j).S1;
        %        S(i,j).S2=combnk(SS,2);
    end
end

%% Find the minMu for each pair i~j
for i=1:p
    for j=i+1:p
        for l=1:length(S(i,j).S1)
            % find S=-,j=+
            temp=S(i,j).S1(l);
%             prob1=exp([-1,-1]*[0,J(j,temp);J(temp,j),0]*[-1;-1]);
%             prob2=exp([1,-1]*[0,J(j,temp);J(temp,j),0]*[1;-1]);
%             
%             prob3=exp([-1,1]*[0,J(j,temp);J(temp,j),0]*[-1;1]);
%             prob4=exp([1,1]*[0,J(j,temp);J(temp,j),0]*[1;1]);
            
            prob1_=sum(LearningData(:,j)==-1 &   LearningData(:,temp)==-1);
            prob2_=sum(LearningData(:,j)==1  &   LearningData(:,temp)==-1);
            prob3_=sum(LearningData(:,j)==-1 &   LearningData(:,temp)==1) ;
            prob4_=sum(LearningData(:,j)==1  &   LearningData(:,temp)==1) ;
            
%            sum1=prob1+prob2+prob3+prob4;
            sum1_=prob1_+prob2_+prob3_+prob4_;
%             prob1=prob1/sum1
%             prob2=prob2/sum1
%             prob3=prob3/sum1
%             prob4=prob4/sum1
            prob1_=prob1_/sum1_;
            prob2_=prob2_/sum1_;
            prob3_=prob3_/sum1_;
            prob4_=prob4_/sum1_;
            
%             prob11=exp([1,-1,-1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[1;-1;-1]);
%             prob12=exp([-1,-1,-1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[-1;-1;-1]);
%             
%             prob21=exp([1,1,-1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[1;1;-1]);
%             prob22=exp([-1,1,-1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[-1;1;-1]);
%             
%             
%             prob31=exp([1,-1,1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[1;-1;1]);
%             prob32=exp([-1,-1,1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[-1;-1;1]);
%             
%             prob41=exp([1,1,1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[1;1;1]);
%             prob42=exp([-1,1,1]*[0,J(i,j),J(i,temp);J(j,i),0,J(j,temp);J(temp,i),J(temp,j),0]*[-1;1;1]);
%             
            prob11_=sum(LearningData(:,i)==1  & LearningData(:,j)==-1 &   LearningData(:,temp)==-1);
            prob12_=sum(LearningData(:,i)==-1 & LearningData(:,j)==-1 &   LearningData(:,temp)==-1);
            
            prob21_=sum(LearningData(:,i)==1  & LearningData(:,j)==1  &   LearningData(:,temp)==-1);
            prob22_=sum(LearningData(:,i)==-1 & LearningData(:,j)==1  &   LearningData(:,temp)==-1);
            
            
            prob31_=sum(LearningData(:,i)==1  & LearningData(:,j)==-1 &   LearningData(:,temp)==1);
            prob32_=sum(LearningData(:,i)==-1 & LearningData(:,j)==-1 &   LearningData(:,temp)==1);
            
            prob41_=sum(LearningData(:,i)==1  & LearningData(:,j)==1  &   LearningData(:,temp)==1);
            prob42_=sum(LearningData(:,i)==-1 & LearningData(:,j)==1  &   LearningData(:,temp)==1);
%           sum2=prob11+prob12+prob21+prob22+prob31+prob32+prob41+prob42;
            sum2_=prob11_+prob12_+prob21_+prob22_+prob31_+prob32_+prob41_+prob42_;
            
            
            
            
%             prob11=prob11/sum2
%             prob12=prob12/sum2
%             prob21=prob21/sum2
%             prob22=prob22/sum2
%             
%             prob31=prob31/sum2
%             prob32=prob32/sum2
%             prob41=prob41/sum2
%             prob42=prob42/sum2
            
            prob11_=prob11_/sum2_;
            prob12_=prob12_/sum2_;
            prob21_=prob21_/sum2_;
            prob22_=prob22_/sum2_;
            
            prob31_=prob31_/sum2_;
            prob32_=prob32_/sum2_;
            prob41_=prob41_/sum2_;
            prob42_=prob42_/sum2_;
            
%             a11=prob11/prob1-prob21/prob2;
%             a22=prob12/prob1-prob22/prob2;
%             mu_a=0.5*(abs(a11)+abs(a22))
%             
%             b11=prob31/prob3-prob41/prob4;
%             b22=prob32/prob3-prob42/prob4;
%             mu_b=0.5*(abs(b11)+abs(b22))
            
            
            
            a11_=prob11_/prob1_-prob21_/prob2_;
            a22_=prob12_/prob1_-prob22_/prob2_;
            mu_a_=0.5*(abs(a11_)+abs(a22_));
            
            b11_=prob31_/prob3_-prob41_/prob4_;
            b22_=prob32_/prob3_-prob42_/prob4_;
            mu_b_=0.5*(abs(b11_)+abs(b22_));
            
            
%            mu_Strue=min([mu_a,mu_b])
            Mu_S1(l,1)=min([mu_a_,mu_b_]);
            
            
        end
        [valuemin1,index]=min(Mu_S1);
        indexv=S(i,j).S1(index);
        S(i,j).S2(:,2)=indexv*ones((length(S(i,j).S1)-1),1);
        middlething=S(i,j).S1;
        middlething(middlething==indexv)=[];
        S(i,j).S2(:,1)=middlething;
        
        for l=1:length(S(i,j).S2(:,1))
            %             temp1=S(i,j).S2(l,1);
            %             temp2=S(i,j).S2(l,2);
            %             prob1=exp([-1,-1,-1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[-1;-1;-1]);
            %             prob2=exp([1,-1,-1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[1;-1;-1]);
            %
            %             prob3=exp([-1,1,-1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[-1;1;-1]);
            %             prob4=exp([1,1,-1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[1;1;-1]);
            %
            %             prob5=exp([-1,-1,1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[-1;-1;1]);
            %             prob6=exp([1,-1,1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[1;-1;1]);
            %
            %             prob7=exp([-1,1,1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[-1;1;1]);
            %             prob8=exp([1,1,1]*[0,J(j,temp1),J(j,temp2);J(temp1,j),0,J(temp1,temp2);J(temp2,j),J(temp2,temp1),0]*[1;1;1]);
            %             sum=prob1+prob2+prob3+prob4+prob5+prob6+prob7+prob8;
            %             prob1=prob1/sum;
            %             prob2=prob2/sum;
            %             prob3=prob3/sum;
            %             prob4=prob4/sum;
            %             prob5=prob5/sum;
            %             prob6=prob6/sum;
            %             prob7=prob7/sum;
            %             prob8=prob8/sum;
            %
            %             prob11=exp([1,-1,-1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;-1;-1;-1]);
            %             prob12=exp([-1,-1,-1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;-1;-1;-1]);
            %
            %             prob21=exp([1,1,-1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;1;-1;-1]);
            %             prob22=exp([-1,1,-1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;1;-1;-1]);
            %
            %
            %             prob31=exp([1,-1,1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;-1;1;-1]);
            %             prob32=exp([-1,-1,1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;-1;1;-1]);
            %
            %             prob41=exp([1,1,1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;1;1;-1]);
            %             prob42=exp([-1,1,1,-1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;1;1;-1]);
            %
            %             prob51=exp([1,-1,-1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;-1;-1;1]);
            %             prob52=exp([-1,-1,-1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;-1;-1;1]);
            %
            %             prob61=exp([1,1,-1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;1;-1;1]);
            %             prob62=exp([-1,1,-1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;1;-1;1]);
            %
            %
            %             prob71=exp([1,-1,1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;-1;1;1]);
            %             prob72=exp([-1,-1,1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;-1;1;1]);
            %
            %             prob81=exp([1,1,1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[1;1;1;1]);
            %             prob82=exp([-1,1,1,1]*[0,J(i,j),J(i,temp1),J(i,temp2);J(j,i),0,J(j,temp1),J(j,temp2);J(temp1,i),J(temp1,j),0,J(temp1,temp2);J(temp2,i),J(temp2,j),J(temp2,temp1),0]*[-1;1;1;1]);
            %
            %             summ=prob11+prob12+prob21+prob22+prob31+prob32+prob41+prob42+prob51+prob52+prob61+prob62+prob71+prob72+prob81+prob82;
            %
            %
            %             prob11=prob11/summ;
            %             prob12=prob12/summ;
            %             prob21=prob21/summ;
            %             prob22=prob22/summ;
            %             prob31=prob31/summ;
            %             prob32=prob32/summ;
            %             prob41=prob41/summ;
            %             prob42=prob42/summ;
            %             prob51=prob51/summ;
            %             prob52=prob52/summ;
            %             prob61=prob61/summ;
            %             prob62=prob62/summ;
            %             prob71=prob71/summ;
            %             prob72=prob72/summ;
            %             prob81=prob81/summ;
            %             prob82=prob82/summ;
            %
            %
            %             a11=prob11/prob1-prob21/prob2;
            %             a22=prob12/prob1-prob22/prob2;
            %             mu_a=0.5*(abs(a11)+abs(a22));
            %
            %
            %
            %             b11=prob31/prob3-prob41/prob4;
            %             b22=prob32/prob3-prob42/prob4;
            %             mu_b=0.5*(abs(b11)+abs(b22));
            %
            %             c11=prob51/prob5-prob61/prob6;
            %             c22=prob52/prob5-prob62/prob6;
            %             mu_c=0.5*(abs(c11)+abs(c22));
            %
            %             d11=prob71/prob7-prob81/prob8;
            %             d22=prob72/prob7-prob82/prob8;
            %             mu_d=0.5*(abs(d11)+abs(d22));
            %             Mu_S2(l,1)=min([mu_a,mu_b,mu_c,mu_d]);
            
            % find S=- -,j=+
            a1=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==1;
            a2=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==-1;
            a11=sum(LearningData(a1,i)==1)/sum(a1)  -   sum(LearningData(a2,i)==1)/sum(a2);
            a22=sum(LearningData(a1,i)==-1)/sum(a1) -   sum(LearningData(a2,i)==-1)/sum(a2);
            mu_a=0.5*(abs(a11)+abs(a22));
            
            % find Separator S=- +;
            b1=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==1;
            b2=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==-1;
            b11=sum(LearningData(b1,i)==1)/sum(b1) -   sum(LearningData(b2,i)==1)/sum(b2);
            b22=sum(LearningData(b1,i)==-1)/sum(b1) -   sum(LearningData(b2,i)==-1)/sum(b2);
            mu_b=0.5*(abs(b11)+abs(b22));
            
            % find Separator S=+ -;
            c= LearningData(:,S(i,j).S2(l,1))==1;
            cc=find(LearningData(c,S(i,j).S2(l,2))==-1);
            % find S=+ -,j=+
            c1=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==1;
            c2=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==-1;
            c11=sum(LearningData(c1,i)==1)/sum(c1)  -   sum(LearningData(c2,i)==1)/sum(c2);
            c22=sum(LearningData(c1,i)==-1)/sum(c1) -   sum(LearningData(c2,i)==-1)/sum(c2);
            mu_c=0.5*(abs(c11)+abs(c22));
            
            % find Separator S=+ +;
            d1=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==1;
            d2=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==-1;
            d11=sum(LearningData(d1,i)==1)/sum(d1) -   sum(LearningData(d2,i)==1)/sum(d2);
            d22=sum(LearningData(d1,i)==-1)/sum(d1) -   sum(LearningData(d2,i)==-1)/sum(d2);
            mu_d=0.5*(abs(d11)+abs(d22));
            % find the minmimun among different values of S
            Mu_S2(l,1)=min([mu_a,mu_b,mu_c,mu_d]);
            
        end
        [valuemin2,index]=min(Mu_S2);
        %indexv2=S(i,j).S2(index,:);
        minMu_S(i,j)=min([valuemin1,valuemin2]);
        %minMu_S(i,j)=valuemin1;
    end
end
