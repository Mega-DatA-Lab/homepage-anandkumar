function minMu_S= minMu_S4(LearningData)
%% Enumerate separator sets
p=length(LearningData(1,:));
minMu_S=zeros(p,p);
for i=1:p
    for j=i+1:p
        SS=1:p;
        SS(i)=[]; SS(j-1)=[];
        S(i,j).S1=combnk(SS,1);
        %          S(i,j).S2=combnk(SS,2);
        %          S(i,j).S3=combnk(SS,3);
        %          S(i,j).S4=combnk(SS,4);
    end
end

%% Find the minMu for each pair i~j

for i=1:p
    for j=i+1:p
        for l=1:length(S(i,j).S1)
            % find S=-,j=+
            a1=LearningData(:,S(i,j).S1(l))==-1&LearningData(:,j)==1;
            a2=LearningData(:,S(i,j).S1(l))==-1&LearningData(:,j)==-1;
                    a11=sum(LearningData(a1,i)==1)/sum(a1)-sum(LearningData(a2,i)==1)/sum(a2);
                    a22=sum(LearningData(a1,i)==-1)/sum(a1)-sum(LearningData(a2,i)==-1)/sum(a2);
            mu_a=0.5*(abs(a11)+abs(a22));
            
            % find S=+,j=-           
            b1=LearningData(:,S(i,j).S1(l))==1&LearningData(:,j)==1;
            b2=LearningData(:,S(i,j).S1(l))==1&LearningData(:,j)==-1;
                    b11=sum(LearningData(b1,i)==1)/sum(b1)-sum(LearningData(b2,i)==1)/sum(b2);
                    b22=sum(LearningData(b1,i)==-1)/sum(b1)-sum(LearningData(b2,i)==-1)/sum(b2);
            mu_b=0.5*(abs(b11)+abs(b22));
            % find the minmimun among different values of S
            Mu_S1(l,1)=min([mu_a,mu_b]);
            clear a; clear a1; clear a2; clear a11; clear a22; clear b; clear b1; clear b2; clear b11; clear b22;
            clear mu_a; clear mu_b;
        end
        [valuemin1,index]=min(Mu_S1);
        indexv=S(i,j).S1(index);
        S(i,j).S2(:,2)=indexv*ones((length(S(i,j).S1)-1),1);
        middlething=S(i,j).S1;
        middlething(middlething==indexv)=[];
        S(i,j).S2(:,1)=middlething;
        %%
        for l=1:length(S(i,j).S2(:,1))
            % find S=- -,j=+
            a1=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==1;
            a2=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==-1;
                    a11=sum(LearningData(a1,i)==1)/sum(a1)  -   sum(LearningData(a2,i)==1)/sum(a2);
                    a22=sum(LearningData(a1,i)==-1)/sum(a1) -   sum(LearningData(a2,i)==-1)/sum(a2);
            mu_a=0.5*(abs(a11)+abs(a22));
            
            % find Separator S=- +;
            b1=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==1;
            b2=LearningData(:,S(i,j).S2(l,1))==-1   &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==-1;
                     b11=sum(LearningData(b1,i)==1)/sum(b1) -   sum(LearningData(b2,i)==1)/sum(b2);
                    b22=sum(LearningData(b1,i)==-1)/sum(b1) -   sum(LearningData(b2,i)==-1)/sum(b2);
            mu_b=0.5*(abs(b11)+abs(b22));
            
            % find Separator S=+ -;
            c= LearningData(:,S(i,j).S2(l,1))==1;
            cc=find(LearningData(c,S(i,j).S2(l,2))==-1);
            % find S=+ -,j=+
            c1=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==1;
            c2=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==-1  &   LearningData(:,j)==-1;
                    c11=sum(LearningData(c1,i)==1)/sum(c1)  -   sum(LearningData(c2,i)==1)/sum(c2);
                    c22=sum(LearningData(c1,i)==-1)/sum(c1) -   sum(LearningData(c2,i)==-1)/sum(c2);
            mu_c=0.5*(abs(c11)+abs(c22));
            
            % find Separator S=+ +;
            d1=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==1;
            d2=LearningData(:,S(i,j).S2(l,1))==1    &   LearningData(:,S(i,j).S2(l,2))==1   &   LearningData(:,j)==-1;
                     d11=sum(LearningData(d1,i)==1)/sum(d1) -   sum(LearningData(d2,i)==1)/sum(d2);
                    d22=sum(LearningData(d1,i)==-1)/sum(d1) -   sum(LearningData(d2,i)==-1)/sum(d2);
            mu_d=0.5*(abs(d11)+abs(d22));
            % find the minmimun among different values of S
            Mu_S2(l,1)=min([mu_a,mu_b,mu_c,mu_d]);
            clear a;clear aa; clear a1; clear a2; clear a11; clear a22; clear b; clear bb;clear b1; clear b2; clear b11; clear b22;
            clear c; clear cc;clear c1; clear c2; clear c11; clear c22;clear d; clear dd;clear d1; clear d2; clear d11; clear d22;
            clear mu_a; clear mu_b; clear mu_c; clear mu_d;
        end
        [valuemin2,index2]=min(Mu_S2);
        indexv2=S(i,j).S2(index2,:);
        S(i,j).S3(:,3)=indexv*ones(length(S(i,j).S2(:,1))-1,1);
        S(i,j).S3(:,2)=indexv2(:,1)*ones(length(S(i,j).S2(:,1))-1,1);
        middlething2=S(i,j).S2(:,1);
        middlething2(middlething2==indexv2(:,1))=[];
        S(i,j).S3(:,1)=middlething2;
        %%
        for l=1:length(S(i,j).S3(:,1))
            % find Separator S=- - -;
            a1=LearningData(:,S(i,j).S3(l,1))==-1	&   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==-1	&   LearningData(:,j)==1;
            a2=LearningData(:,S(i,j).S3(l,1))==-1	&   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==-1	&   LearningData(:,j)==-1;
            a11=sum(LearningData(a1,i)==1)/sum(a1)-sum(LearningData(a2,i)==1)/sum(a2);
            a22=sum(LearningData(a1,i)==-1)/sum(a1)-sum(LearningData(a2,i)==-1)/sum(a2);
            mu_a=0.5*(abs(a11)+abs(a22));
            
            % find Separator S=- - +;
            b1=LearningData(:,S(i,j).S3(l,1))==-1	&   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==1   &   LearningData(:,j)==1;
            b2=LearningData(:,S(i,j).S3(l,1))==-1	&   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==1   &   LearningData(:,j)==-1;
            b11=sum(LearningData(b1,i)==1)/sum(b1)-sum(LearningData(b2,i)==1)/sum(b2);
            b22=sum(LearningData(b1,i)==-1)/sum(b1)-sum(LearningData(b2,i)==-1)/sum(b2);
            mu_b=0.5*(abs(b11)+abs(b22));
            
            % find Separator S=- + -;
            c1=LearningData(:,S(i,j).S3(l,1))==-1	&	LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==-1  &   LearningData(:,j)==1;
            c2=LearningData(:,S(i,j).S3(l,1))==-1	&   LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==-1  &   LearningData(:,j)==-1;
            c11=sum(LearningData(c1,i)==1)/sum(c1)-sum(LearningData(c2,i)==1)/sum(c2);
            c22=sum(LearningData(c1,i)==-1)/sum(c1)-sum(LearningData(c2,i)==-1)/sum(c2);
            mu_c=0.5*(abs(c11)+abs(c22));
            
            % find Separator S=+ - -;
            d1=LearningData(:,S(i,j).S3(l,1))==-1	&	LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==1  &   LearningData(:,j)==1;
            d2=LearningData(:,S(i,j).S3(l,1))==-1	&	LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==1  &   LearningData(:,j)==-1;
            d11=sum(LearningData(d1,i)==1)/sum(d1)-sum(LearningData(d2,i)==1)/sum(d2);
            d22=sum(LearningData(d1,i)==-1)/sum(d1)-sum(LearningData(d2,i)==-1)/sum(d2);
            mu_d=0.5*(abs(d11)+abs(d22));
            
            % find Separator S=- - +;
            e1=LearningData(:,S(i,j).S3(l,1))==1    &   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==-1 &   LearningData(:,j)==1;
            e2=LearningData(:,S(i,j).S3(l,1))==1    &   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==-1 &   LearningData(:,j)==-1;
            e11=sum(LearningData(e1,i)==1)/sum(e1)-sum(LearningData(e2,i)==1)/sum(e2);
            e22=sum(LearningData(e1,i)==-1)/sum(e1)-sum(LearningData(e2,i)==-1)/sum(e2);
            mu_e=0.5*(abs(e11)+abs(e22));
            
            % find Separator S=- - +;
            f1=LearningData(:,S(i,j).S3(l,1))==1    &   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==1  &   LearningData(:,j)==1;
            f2=LearningData(:,S(i,j).S3(l,1))==1    &   LearningData(:,S(i,j).S3(l,2))==-1  &   LearningData(:,S(i,j).S3(l,3))==1  &   LearningData(:,j)==-1;
            f11=sum(LearningData(f1,i)==1)/sum(f1)-sum(LearningData(f2,i)==1)/sum(f2);
            f22=sum(LearningData(f1,i)==-1)/sum(f1)-sum(LearningData(f2,i)==-1)/sum(f2);
            mu_f=0.5*(abs(f11)+abs(f22));
            
            % find Separator S=- - +;
            g1=LearningData(:,S(i,j).S3(l,1))==1   &   LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==-1 &   LearningData(:,j)==1;
            g2=LearningData(:,S(i,j).S3(l,1))==1   &   LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==-1 &   LearningData(:,j)==-1;
            g11=sum(LearningData(g1,i)==1)/sum(g1)-sum(LearningData(g2,i)==1)/sum(g2);
            g22=sum(LearningData(g1,i)==-1)/sum(g1)-sum(LearningData(g2,i)==-1)/sum(g2);
            mu_g=0.5*(abs(g11)+abs(g22));
            
            % find Separator S=- - +;
            h1=LearningData(:,S(i,j).S3(l,1))==1   &   LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==1  &   LearningData(:,j)==1;
            h2=LearningData(:,S(i,j).S3(l,1))==1   &   LearningData(:,S(i,j).S3(l,2))==1   &   LearningData(:,S(i,j).S3(l,3))==1  &   LearningData(:,j)==-1;
            h11=sum(LearningData(h1,i)==1)/sum(h1)-sum(LearningData(h2,i)==1)/sum(h2);
            h22=sum(LearningData(h1,i)==-1)/sum(h1)-sum(LearningData(h2,i)==-1)/sum(h2);
            mu_h=0.5*(abs(h11)+abs(h22));
            Mu_S3(l,1)=min([mu_a,mu_b,mu_c,mu_d,mu_e,mu_f,mu_g,mu_h]);
            
        end
        
        [valuemin3,index3]=min(Mu_S3);
        indexv3=S(i,j).S3(index3,:);
        S(i,j).S4(:,4)=indexv*ones(length(S(i,j).S3(:,1))-1,1);
        S(i,j).S4(:,3)=indexv2(:,1)*ones(length(S(i,j).S3(:,1))-1,1);
        S(i,j).S4(:,2)=indexv3(:,1)*ones(length(S(i,j).S3(:,1))-1,1);
        middlething3=S(i,j).S3(:,1);
        middlething3(middlething3==indexv3(:,1))=[];
        S(i,j).S4(:,1)=middlething3;
        %%
        for l=1:length(S(i,j).S4(:,1))
            a1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            a2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            a11=sum(LearningData(a1,i)==1)/sum(a1)-sum(LearningData(a2,i)==1)/sum(a2);
            a22=sum(LearningData(a1,i)==-1)/sum(a1)-sum(LearningData(a2,i)==-1)/sum(a2);
            mu_a=0.5*(abs(a11)+abs(a22));
            
            
            b1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            b2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            b11=sum(LearningData(b1,i)==1)/sum(b1)-sum(LearningData(b2,i)==1)/sum(b2);
            b22=sum(LearningData(b1,i)==-1)/sum(b1)-sum(LearningData(b2,i)==-1)/sum(b2);
            mu_b=0.5*(abs(b11)+abs(b22));
            
            c1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            c2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            c11=sum(LearningData(c1,i)==1)/sum(c1)-sum(LearningData(c2,i)==1)/sum(c2);
            c22=sum(LearningData(c1,i)==-1)/sum(c1)-sum(LearningData(c2,i)==-1)/sum(c2);
            mu_c=0.5*(abs(c11)+abs(c22));
            
            d1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            d2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            d11=sum(LearningData(d1,i)==1)/sum(d1)-sum(LearningData(d2,i)==1)/sum(d2);
            d22=sum(LearningData(d1,i)==-1)/sum(d1)-sum(LearningData(d2,i)==-1)/sum(d2);
            mu_d=0.5*(abs(d11)+abs(d22));
            
            e1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            e2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            e11=sum(LearningData(e1,i)==1)/sum(e1)-sum(LearningData(e2,i)==1)/sum(e2);
            e22=sum(LearningData(e1,i)==-1)/sum(e1)-sum(LearningData(e2,i)==-1)/sum(e2);
            mu_e=0.5*(abs(e11)+abs(e22));
            
            f1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            f2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            f11=sum(LearningData(f1,i)==1)/sum(f1)-sum(LearningData(f2,i)==1)/sum(f2);
            % find i=-|S=- - +,j=+ minus i=-|S=- - +,j=-
            f22=sum(LearningData(f1,i)==-1)/sum(f1)-sum(LearningData(f2,i)==-1)/sum(f2);
            mu_f=0.5*(abs(f11)+abs(f22));
            
            g1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            g2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            g11=sum(LearningData(g1,i)==1)/sum(g1)-sum(LearningData(g2,i)==1)/sum(g2);
            g22=sum(LearningData(g1,i)==-1)/sum(g1)-sum(LearningData(g2,i)==-1)/sum(g2);
            mu_g=0.5*(abs(g11)+abs(g22));
            
            h1=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            h2=LearningData(:,S(i,j).S4(l,1))==-1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            h11=sum(LearningData(h1,i)==1)/sum(h1)-sum(LearningData(h2,i)==1)/sum(h2);
            h22=sum(LearningData(h1,i)==-1)/sum(h1)-sum(LearningData(h2,i)==-1)/sum(h2);
            mu_h=0.5*(abs(h11)+abs(h22));
            
            I1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            I2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            I11=sum(LearningData(I1,i)==1)/sum(I1)-sum(LearningData(I2,i)==1)/sum(I2);
            I22=sum(LearningData(I1,i)==-1)/sum(I1)-sum(LearningData(I2,i)==-1)/sum(I2);
            mu_I=0.5*(abs(I11)+abs(I22));
            
            J1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            J2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            J11=sum(LearningData(J1,i)==1)/sum(J1)-sum(LearningData(J2,i)==1)/sum(J2);
            J22=sum(LearningData(J1,i)==-1)/sum(J1)-sum(LearningData(J2,i)==-1)/sum(J2);
            mu_J=0.5*(abs(J11)+abs(J22));
            
            K1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            K2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            K11=sum(LearningData(K1,i)==1)/sum(K1)-sum(LearningData(K2,i)==1)/sum(K2);
            K22=sum(LearningData(K1,i)==-1)/sum(K1)-sum(LearningData(K2,i)==-1)/sum(K2);
            mu_K=0.5*(abs(K11)+abs(K22));
            
            L1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            L2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==-1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            L11=sum(LearningData(L1,i)==1)/sum(L1)-sum(LearningData(L2,i)==1)/sum(L2);
            L22=sum(LearningData(L1,i)==-1)/sum(L1)-sum(LearningData(L2,i)==-1)/sum(L2);
            mu_L=0.5*(abs(L11)+abs(L22));
            
            
            M1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            M2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            M11=sum(LearningData(M1,i)==1)/sum(M1)-sum(LearningData(M2,i)==1)/sum(M2);
            M22=sum(LearningData(M1,i)==-1)/sum(M1)-sum(LearningData(M2,i)==-1)/sum(M2);
            mu_M=0.5*(abs(M11)+abs(M22));
            
            
            N1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            N2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==-1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            N11=sum(LearningData(N1,i)==1)/sum(N1)-sum(LearningData(N2,i)==1)/sum(N2);
            N22=sum(LearningData(N1,i)==-1)/sum(N1)-sum(LearningData(N2,i)==-1)/sum(N2);
            mu_N=0.5*(abs(N11)+abs(N22));
            
            O1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==1; 
            O2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==-1  &   LearningData(:,j)==-1; 
            O11=sum(LearningData(O1,i)==1)/sum(O1)-sum(LearningData(O2,i)==1)/sum(O2);
            O22=sum(LearningData(O1,i)==-1)/sum(O1)-sum(LearningData(O2,i)==-1)/sum(O2);
            mu_O=0.5*(abs(O11)+abs(O22));          
            
            
            V1=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==1; 
            V2=LearningData(:,S(i,j).S4(l,1))==1   &   LearningData(:,S(i,j).S4(l,2))==1  &   LearningData(:,S(i,j).S4(l,3))==1 & LearningData(:,S(i,j).S4(l,4))==1  &   LearningData(:,j)==-1; 
            V11=sum(LearningData(V1,i)==1)/sum(V1)-sum(LearningData(V2,i)==1)/sum(V2);
            V22=sum(LearningData(V1,i)==-1)/sum(V1)-sum(LearningData(V2,i)==-1)/sum(V2);
            mu_V=0.5*(abs(V11)+abs(V22));
            
            Mu_S4(l,1)=min([mu_a,mu_b,mu_c,mu_d,mu_e,mu_f,mu_g,mu_h,mu_I,mu_J,mu_K,mu_K,mu_M,mu_N,mu_O,mu_V]);
        end
        [valuemin4,index3]=min(Mu_S4);
        %%
        minMu_S(i,j)=min([valuemin1,valuemin2,valuemin3,valuemin4]);
    end
end
