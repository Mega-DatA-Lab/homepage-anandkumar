clear all
clc
p=80;beta=0.1;alpha=0.2-beta;

k=2;c=1;nStates = 2;
pathdef;

Jcycle=graph2adj_cycle(p,alpha,beta);
adjcycle=Jcycle;adjcycle(Jcycle~=0)=1;
k_cy=sum(sum(adjcycle));

JER=graph2adj_ER(p,c,alpha,beta);
adjER=JER;adjER(JER~=0)=1;
k_ER=sum(sum(adjER));

JWS=graph2adj_WS(p,k,c,alpha,beta);
adjWS=JWS;adjWS(JWS~=0)=1;
k_WS=sum(sum(adjWS));

%% non-attractive// Without this for loop, it will be attractive model
for i=1:length(Jcycle(:))
    if rand(1)<0.5
        Jcycle(i)=-Jcycle(i);
        JER(i)=-JER(i);
        JWS(i)=-JWS(i);
    end
        
end

%% Algorithm begins
runs=1;
for n=[100,500,1000,5000,10000,100000]
    LearningDatacycle=double(SampleLearn(p, nStates, n,adjcycle, Jcycle));
    minMuS(runs).cycle= minMu_S2(LearningDatacycle);
    LearningDataER=double(SampleLearn(p, nStates, n,adjER, JER));
    minMuS(runs).ER= minMu_S2(LearningDataER);
    LearningDataWS=double(SampleLearn(p, nStates, n,adjWS, JWS));
    minMuS(runs).WS= minMu_S4(LearningDataWS);
    
    Thres=[0.00005,0.00006,0.00007,0.00008,0.00009,0.0001,0.0002,0.0003,0.0004,0.0005,0.0006,0.0007,0.0008,0.0009,0.0010,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009,0.010,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.10];
   
    for tt=1:length(Thres)
        %% CYCLE
        J_candidate=eye(p);
        J_candidate(minMuS(runs).cycle>=Thres(tt))=1;
        J_candidate=(triu(J_candidate,1))'+triu(J_candidate,1);
        adjhatcycle=J_candidate;
        
        E1cycle=double(xor(adjcycle,adjhatcycle));
        noEdges_cycle(runs,tt)=sum(sum(triu(adjhatcycle,1)));
        norEditDiscycle(runs,tt)=sum(sum(E1cycle))/k_cy;
        
        
        %% ER
        J_candidate=eye(p);
        J_candidate(minMuS(runs).ER>=Thres(tt))=1;
        J_candidate=(triu(J_candidate,1))'+triu(J_candidate,1);
        adjhatER=J_candidate;
        
        E1ER=double(xor(adjER,adjhatER));
        noEdges_er(runs,tt)=sum(sum(triu(adjhatER,1)));
        norEditDisER(runs,tt)=sum(sum(E1ER))/k_ER;
        
        
        %% WS
        J_candidate=eye(p);
        J_candidate(minMuS(runs).WS>=Thres(tt))=1;
        J_candidate=(triu(J_candidate,1))'+triu(J_candidate,1);
        adjhatWS=J_candidate;
        
        E1WS=double(xor(adjWS,adjhatWS));
        noEdges_ws(runs,tt)=sum(sum(triu(adjhatWS,1)));
        norEditDisWS(runs,tt)=sum(sum(E1WS))/k_WS;
    end
    runs=runs+1;
end